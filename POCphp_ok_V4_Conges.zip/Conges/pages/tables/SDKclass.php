<?php
class  camundaTask{
        private $engine;
        private $pathSeparator;

  /**
   * Récupère une seule tâche par son identifiant.
   * @link http://docs.camunda.org/api-references/rest/#!/task/get
   *
   * @param String $id task id
   * @return mixed
   */
  public function getSingleTask($id) {
    $query = 'task/'.$id;
    return $this->restRequest('GET', $query, null);
  }

   /**
   * obtenir toutes les tâches du reste de l'API
   * @link http://docs.camunda.org/api-references/rest/#!/task/get-query
   *
   * @param Array $parameterArray url parameter
   * @param bool $isPostRequest triggers a post request instead a get request
   * @return mixed returns the server-response
   */
  public function getTasks($parameterArray = null, $isPostRequest = false) {
    $query = 'task';
    if (!$isPostRequest) {
      return $this->restRequest('GET', $query, $parameterArray);
    } else {
      return $this->restRequest('POST', $query, $parameterArray);
    }
  }


  
  /**
   * Effectuez une tâche et mettez à jour les variables de processus.
   * @link http://docs.camunda.org/api-references/rest/#!/task/post-complete
   *
   * @param String $id id of the task
   * @param Array $parameterArray url parameter
   * @return mixed returns the server response
   */
  public function completeTask($id,$parameterArray) {
    $query = 'task/'.$id.'/complete';
    return $this->restRequest('POST', $query, $parameterArray);
  }

}

?>
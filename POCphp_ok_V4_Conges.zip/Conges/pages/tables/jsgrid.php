<html lang="en">
<?php 
//ouverture d'une connexion à la base de données test 
$objetPDO = new PDO ('mysql:host=localhost; dbname=bdcamundatest','root','');
//prepâration de la requete de recuperation des donnees de la bd
$PDOstart = $objetPDO->prepare('SELECT * FROM conges');
//execution de la requete
$recuperation=$PDOstart->execute();
//recuperation de tous  les conges dans la table conges
$conges =$PDOstart->fetchAll();
//var_dump($conges);//exit;


?>  

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Demande traitees</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- jsGrid -->
  <link rel="stylesheet" href="../../plugins/jsgrid/jsgrid.min.css">
  <link rel="stylesheet" href="../../plugins/jsgrid/jsgrid-theme.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">

<div class="card-body">

<!--position initial du tableau des demandes -->
</div>
<div class="wrapper"> 
   <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="https://www.cie.ci/" class="brand-link">
      <img src="../../dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">CIE</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="../../dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">Etienne traore</a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false"><!-- ajout d'element dans la pallette gauche -->
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                <a href="data.php">DEMANDES EN COURS</a>
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Demandes traitées</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
    <table id="DemandesEncours" class="table table-bordered table-hover">
    <thead>
      <tr>
        <th>N°</th>
        <th>NOM</th>
        <th>PRENOM (S)</th>
        <th>POSTE</th>
        <th>SERVICE</th>
        <th>DATE DE DEPART</th>
        <th>JOURS</th>
        <th>E-MAIL</th>
        <th>STATUT</th>
      </tr>
    </thead>
  
    <tbody>
      
      <!--une boucle pour remplir les lignes du tableau-->
      <?php foreach ($conges as $key => $value): ?>
      <tr>
        <td><?=$key+1?></td>
        <td><?=$value['nom']?></td>
        <td><?=$value['prenom']?></td>
        <td><?=$value['poste']?></td>
        <td><?=$value['services']?></td>
        <td><?=$value['datedepart']?></td>
        <td><?=$value['jours']?></td>
        <td><?=$value['email']?></td>
        <td><?=$value['statut']?></td>
    </tr>
    <?php endforeach ?>
    </tbody>
  </table>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b>1.0
    </div>
    <strong>Copyright &copy; 2014-2021 <a href="www.cie.ci">CIE-GS2E</a>.</strong> Tous droits r&servés.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- jsGrid -->
<script src="../../plugins/jsgrid/demos/db.js"></script>
<script src="../../plugins/jsgrid/jsgrid.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
<!-- liste des demandes traité -->
<script>
  $(function () {
    $("#jsGrid1").jsGrid({
        height: "100%",
        width: "100%",

        sorting: true,
        paging: true,

        data: db.clients,
          fields: [
            { name: "nom", type: "text", width: 150 , title:"NOM"},
            { name: "prenom", type: "text", width: 250, title:"PRENOMS" },
            { name: "poste", type: "text", width: 100, title: "POSTE" },
            { name: "service", type: "text",title: "SERVICE" },
            { name: "jours", type: "number", title: "NOMBRE DE JOURS" },
             { name: "depart", type: "date", title: "date de depart" }
        ]
    });
  });
</script>
</body>
</html>

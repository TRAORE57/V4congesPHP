<?php
// chargement de la fonction d'insertion
require_once 'saveToDatabase.php'; 
//enregistrement en base
$isSave = saveToDatabase(array(
    'statut'=> 'REFUSE',
    'nom'=>$_POST['nom'],
    'prenom'=>$_POST['prenom'],
    'services'=>$_POST['service'],
    'poste'=>$_POST['poste'], 
    'jours'=>$_POST['jours'],
    'datedepart'=>$_POST['datedepart'],
    'email'=>$_POST['mail'],
    'uploadfile'=>$_POST['uploadfile']
));
//parametre et nom de celui qui est sensé terminer la tache
$params= [
	"variables"=>[
		"approver"=>[
			"value"=>'demo',
			"type"=>'string'
		]
	] 
];
$motif=$_POST['motif']; 
//$email=$_POST['email'];

//id de la tache
$tacheId = $_GET['tacheId'];
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');

//var_dump($fini);
use PHPMailer\PHPMailer\PHPMailer; 
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
 
require_once __DIR__ . '/vendor/phpmailer/src/Exception.php';
require_once __DIR__ . '/vendor/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/vendor/phpmailer/src/SMTP.php';

//passer true dans le constructeur, active les exceptions dans PHPMailer
$mail = new PHPMailer(true);

try {
    // configuration serveur
    $mail->SMTPDebug = SMTP::DEBUG_SERVER; // pour les details de debeugage
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->Username = 'etiobotra@gmail.com'; // mon  email de gmail
    $mail->Password = 'PAPAthio57.'; // mon mot de passe gmail

    // Paramètres de l'expéditeur et du destinataire
    $mail->setFrom('etiobotra@gmail.com', "TRAORE "); //expediteur
    $mail->addAddress('etiobotra@gmail.com', 'TRAORE OBONAN ');
    $mail->addReplyTo('etiobotra@gmail.com', "TRAORE OBONAN ETIENNE"); // reponse mail
    // contenu du mail
    $mail->IsHTML(true);
    $mail->Subject = "AVIS DU RESPONSABLE";
    $mail->Body = "VOTRE DEMANDE DE CONGE A ETE REFUSE PAR LE RESPONSABLE <br>MOTIF<br/> : $motif";
    $mail->AltBody = 'Plain text message body for non-HTML email client. Gmail SMTP email body.';

    $mail->send();
    echo "Message électronique envoyé.";
} catch (Exception $e) {
    echo "Erreur lors de l'envoi du courrier électronique. Erreur de l'expéditeur: {$mail->ErrorInfo}";
}
$fini =$restClient->completeTask($tacheId,$params);
header('Location: data.php');

?>
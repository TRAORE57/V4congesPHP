<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>E-Demande.CIE</title>
  <link rel="stylesheet" href="styl.css" />

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini">
  <div class="wrapper">

    <!-- bloque logo cie -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Brand Logo -->
      <a href="https://www.cie.ci/" class="brand-link">
        <img src="../../dist/img/AdminLTELogo.png" alt="Logo CIE" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">CIE | Congés</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">
        <!-- Sidebar user (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="../../dist/img/avatar5.png" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="#" class="d-block">Etienne Traoré</a>
          </div>
        </div>

        <!-- SidebarSearch Form -->
        <div class="form-inline">
          <div class="input-group" data-widget="sidebar-search">
            <input class="form-control form-control-sidebar" type="search" placeholder="search" aria-label="Search">
            <div class="input-group-append">
              <button class="btn btn-sidebar">
                <i class="fas fa-search fa-fw"></i>
              </button>
            </div>
          </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <!-- Ajout d'element dans la palette gauche de la page-->
            <li class="nav-item">
              <ul class="nav nav-treeview">
            </li>
          </ul>
          </li>


          <li class="nav-item menu-open">

          <li class="nav-item">
            <a href="../tables/data.php" class="nav-link active">
              <i class="far fa-circle nav-icon"></i>
              <p>Demandes en cours</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="../tables/jsgrid.php" class="nav-link">
              <i class="far fa-circle nav-icon"></i>
              <p>Demandes Traitées</p>
            </a>
          </li>
          </ul>
          </li>

          </ul>
        </nav>
        <!-- /.sidebar-menu -->
      </div>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Demandes de congés</h1>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h2 class="card-title">
                    <strong>Demandes en attente de traitement</strong>
                    <!--  bouton de rafraichisssement de la page -->
                    <button class="jolie" onclick="document.location.reload(false)" name="recuperer"><strong>ACTUALISER LA LISTE</strong> </button>
                    <?php
                    //ouverture du fichier de l'api une seule fois
                  require_once('camundaRestClient.php');
                  // precision du chemin 
                  $restClient = new camundaRestClient('http://localhost:8080/engine-rest');
                  // âppel de la fonction pour recuper l'id du process
                  //$resul =$restClient->getProcessVariables($_GET['processInstanceId']);
                  //recuperation des valeurs du tableau de données obtenus depuis la //reponse CAMUNDA
                  $results = $restClient->getTasks(['assigned'=>true,'assignee'=>'demo']);
                  //var_dump($results); exit;
                    ?>
                  </h2> 
                </div>
                <!-- TABLEAU DE DEMANDES EN COURS -->
                <div class="card-body">

                  <table id="DemandesEncours" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>N°</th>
                        <th>DATE DE DEMANDE</th>
                        <th>NOM DU DEMANDEUR</th>
                        <th>PRENOM(S)DU  DEMANDEUR</th>
                        <th>LIBELLE</th>
                        <th>DETAILS</th>

                      </tr>
                    </thead>

                    <tbody>
                      
                      <!--une boucle pour remplir les lignes du tableau-->
                      <?php foreach ($results as $key => $value): ?>
                      <?php 
                            //l'appel de la fonction pour avoir accès au variables du processus
                          $variable=$restClient->getProcessVariables($value->processInstanceId);
                          //var_dump($variable); exit;
                      ?>
                      <tr>
                        <td><?=$key+1?></td>
                        <td><?=$value->created?></td> 
                        <td><?=$variable->nom->value?></td>
                        <td><?=$variable->prenom->value?></td>
                        <td><?=$value->name?></td>
                        
                        <td>
                          <!--envoi des parametres vers la page suivante "FormTraiter.php"-->
                        <a type="button" class="btn btn-outline-warning" href="FormTraiter.php?processInstanceId=<?=$value->processInstanceId?>&id=<?=$value->id?>" class="favorite styled" name="details"><strong>DETAILS</strong></a>
                     
        						      <a type="button" href="piece.php?piece=<?=$variable->uploadfile->value?>" class="btn btn-outline-info"  > <strong>PIECE</strong></a>
    						     
                        </td>
                    </tr>
                    <?php endforeach ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->

              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
      <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
      </div>
      <strong>Copyright &copy; 2019-2021 <a href="https://www.cie.ci/">CIE-GS2E</a>.</strong> Tous droits reservés
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="../../plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- DataTables  & Plugins -->
  <script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
  <script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
  <script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
  <script src="../../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
  <script src="../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script src="../../plugins/jszip/jszip.min.js"></script>
  <script src="../../plugins/pdfmake/pdfmake.min.js"></script>
  <script src="../../plugins/pdfmake/vfs_fonts.js"></script>
  <script src="../../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
  <script src="../../plugins/datatables-buttons/js/buttons.print.min.js"></script>
  <script src="../../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../../dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../../dist/js/demo.js"></script>
  <!-- Page specific script -->
  <script>
    $(function() {
      $("#DemandesEncours").DataTable({
        "responsive": true,
        "lengthChange": false,
        "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "responsive": true,
      });
    });
  </script>
</body>

</html>
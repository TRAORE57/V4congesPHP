<?php
//var_dump($_FILES);exit;
$uploadFichier = 'fichiers/';
//ajout des secondes au nom du fichier pour ne pas écraser l'autre fichier
$uploadfile = $uploadFichier .time().'-'. basename($_FILES['pieceJointe']['name']);
//deplacement du fichier dans le repertoir ou dossier "fichier"
if (move_uploaded_file($_FILES['pieceJointe']['tmp_name'], $uploadfile)) {
    echo "Le fichier est valide, et a été téléchargé
           avec succès. Voici plus d'informations :\n";
} else {
    echo "Attaque potentielle par téléchargement de fichiers.
          Voici plus d'informations :\n";
}
echo 'Voici quelques informations de débogage :';
//print_r($uploadfile);
 
//exit;

// demarrage du processus et  envoyer des donnees à camunda
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');
// recuperation et envoi des données du formulaire vers camunda
$params=[
		"nom"=>['value'=>$_POST['nom'],'type'=>'string'],
		"prenom"=>['value'=>$_POST['prenom'],'type'=>'string'], 
		"service"=>['value'=>$_POST['service'],'type'=>'string'],
		"poste"=>['value'=>$_POST['poste'],'type'=>'string'],
		"DateDepart"=>['value'=>$_POST['DateDepart'],'type'=>'string'],
		"mail"=>['value'=>$_POST['mail'],'type'=>'string'],
		"jours"=>['value'=>$_POST['jours'],'type'=>'Long'],
		"uploadfile"=>['value'=>$uploadfile, 'type'=>'string']
		];
//var_dump($params); exit;
 
$currentExecution = $restClient->startProcessInstance("conges",["variables"=>$params]);
// var_dump($result);
$executionId=$currentExecution->id; //id du processu courent ou de l'instance en cours
$tache = $restClient->getTasks(['assigned'=>true,'assignee'=>'ac','executionId'=>$executionId]);
//parametre de celui qui est habilité à mettre fin a la tâche
$paramsFin= [ 
	"variables"=>[
		"approver"=>[
			"value"=>'ac',
			"type"=>'string'
		]
	]
];
//var_dump($tache);
//achevenent de la tâche
$acheverTache =$restClient->completeTask($tache[0]->id,$paramsFin);
//var_dump($acheverTache);
echo "demande envoyée";
header('Location: FormConge.php');

?>
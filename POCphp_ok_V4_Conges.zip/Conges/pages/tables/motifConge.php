<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>motif de refus de conges</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title">REFUS DE LA DEMANDE DE CONGE</div>
    <div class="content">
      <form  method="POST" action="RefuserConge.php?tacheId=<?=$_GET['tacheId']?>" enctype='multipart/form-data' >
        <div class="user-details">
          <div class="mb-3">
            <textarea  cols="93" rows="4" name="motif" row="3"></textarea> 
            <input  readonly type="hidden" name="mail" value="<?=$_GET['mail']?>">
            <input  readonly type="hidden" name="nom" value="<?=$_GET['nom']?>">
            <input  readonly type="hidden" name="prenom" value="<?=$_GET['prenom']?>">
            <input  readonly type="hidden" name="poste" value="<?=$_GET['poste']?>">
            <input  readonly type="hidden" name="service" value="<?=$_GET['service']?>">
            <input  readonly type="hidden" name="datedepart" value="<?=$_GET['datedepart']?>">
            <input  readonly type="hidden" name="jours" value="<?=$_GET['jours']?>">
            <input  readonly type="hidden" name="uploadfile" value="<?=$_GET['uploadfile']?>">
          </div>
        </div>
        <div class="button">
          <input type="submit" value="Envoyer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
